#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "ADC_Temp.h"


int main(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_WriteBit(GPIOB,GPIO_Pin_7,Bit_RESET);
	
	ADC_TempInit();
	int numdata;
	u16 temp_ten;
	u16 temp_div;
	OLED_Init();
	while(1){
		numdata=GET_Time_voltage();
		if(numdata<0){
			OLED_ShowChar(1,1,'-');
			temp_ten=numdata/10%10;
			temp_div=numdata%10;
			numdata=numdata/100;
			OLED_ShowNum(1,2,numdata,2);
			OLED_ShowChar(1,4,'.');
			OLED_ShowNum(1,5,temp_ten,1);
			OLED_ShowNum(1,6,temp_div,1);
			OLED_ShowChar(1,7,'`');
			OLED_ShowChar(1,8,'C');
		}
		else{
			temp_ten=numdata/10%10;
			temp_div=numdata%10;
			numdata=numdata/100;
			OLED_ShowNum(1,2,numdata,2);
			OLED_ShowChar(1,4,'.');
			OLED_ShowNum(1,5,temp_ten,1);
			OLED_ShowNum(1,6,temp_div,1);
			OLED_ShowChar(1,7,'`');
			OLED_ShowChar(1,8,'C');
		}
		Delay_ms(1000);
	}
	
}

