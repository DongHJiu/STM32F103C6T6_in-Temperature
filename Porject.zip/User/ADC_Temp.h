#ifndef __ADC_Temp_H
#define __ADC_Temp_H

void ADC_TempInit(void);
u16 GET_ADC(u8 ch);
u16 GET_ADC_Temp(u8 ch,u8 times);
int GET_Time_voltage(void);


#endif
