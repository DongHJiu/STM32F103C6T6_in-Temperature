#include "stm32f10x.h"                  // Device header
#include "Delay.h"



//因为内部温度传感器是内部连接好的,所以不用初始化管脚
//内部温度传感器是连接在ADC1_IN(通道)16上面的
void ADC_TempInit(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);   
	
	
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);                //ADC时钟分频
	ADC_TempSensorVrefintCmd(ENABLE);                //开启内部温度传感器    
	ADC_DeInit(ADC1);                                //复位ADC1
	
	ADC_InitTypeDef ADCFirst;
	ADCFirst.ADC_ContinuousConvMode=DISABLE;         //
	ADCFirst.ADC_DataAlign=ADC_DataAlign_Right;      //设置数据右对齐还是左对齐(这里设置右对齐)
	ADCFirst.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None;           //设置是否外部触发(这里不使用外部触发)
	ADCFirst.ADC_Mode=ADC_Mode_Independent;               //设置为独立模式
	ADCFirst.ADC_NbrOfChannel=1;                          //设置有几个通道
	ADCFirst.ADC_ScanConvMode=DISABLE;                    //是否使用扫描模式(这里设置不适用  )
	ADC_Init(ADC1,&ADCFirst);
	
	ADC_Cmd(ADC1,ENABLE);                                        //使能ADC1
	ADC_ResetCalibration(ADC1);                                  //使能复位校准
	while(ADC_GetResetCalibrationStatus(ADC1));                  //等待复位校准结束
	ADC_StartCalibration(ADC1);                                  //开启AD校准
	while(ADC_GetCalibrationStatus(ADC1));                       //等待校准结束
	
}

/**
  * @brief  获取AD值
  * @param  ch @获取的通道
  * @retval 返回转换的AD值   
  */
u16 GET_ADC(u8 ch){
	ADC_RegularChannelConfig(ADC1,ch,1,ADC_SampleTime_239Cycles5);      //配置规则通道(哪个ADC;哪个通道;在规则序列之间是第几个转换;采样时间)
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);                        //开启软件转换
	while(!ADC_GetFlagStatus(ADC1,ADC_FLAG_EOC));                   //等待转换结束
	return ADC_GetConversionValue(ADC1);                          //返还获取的入口参数
}

/**
  * @brief  循环获取AD值并求出平均值
  * @param  ch @获取的通道(每款STM32的内部温度传感器都有固定连接的通道)  
  * @param  times @总共要获取的次数
  * @retval 循环获取后求出的平均值  
  */
u16 GET_ADC_Temp(u8 ch,u8 times){                           //循环获取后求出平均值
	u32 val=0;
	u8 t;
	for(t=0;t<times;t++){
		val+=GET_ADC(ch);
		Delay_ms(5);
	}
	return val/times;
}

/**
  * @brief  获取内部温度传感器的温度(*100)
  * @param  无
  * @retval 返回内部温度传感器的温度值(*100)  
  */
int GET_Time_voltage(void){
	u16 temp_ADC;
	float temp_volta;
	int tempdata;
	temp_ADC=GET_ADC_Temp(ADC_Channel_16,10);      //内部温度传感器是连接在ADC1_IN(通道)16上面的
	temp_volta=(float)temp_ADC*(3.3/4096);         //把温度AD值转换成温度电压值
	temp_volta=(1.43-temp_volta)/0.0043+25;        //把温度电压值转换成温度值
	tempdata=temp_volta*100;                       //把温度值*100后方便显示后面的小数
	return tempdata;
}
